#include <stdlib.h>
#include <limits.h>  /* for USHRT_MAX */

#include <immintrin.h>

#include "min.h"
/* reference implementation in C */
short min_C(long size, short * a) {
    short result = SHRT_MAX;
    for (int i = 0; i < size; ++i) {
        if (a[i] < result)
            result = a[i];
    }
    return result;
}

short min_AVX(long size, short * a) {
    // generate vector with max short value copies
    __m256i min_vect = _mm256_set1_epi16(SHRT_MAX);

    // compare each vector in array with the current min vector
    for (int i = 0; i < size; i+=16) {
      __m256i curr_vect = _mm256_loadu_si256((__m256i*) &a[i]);
      // set min_vector to the min of curr_vector and min_vector
      min_vect = _mm256_min_epi16(min_vect, curr_vect);
    }

    unsigned short extracted_mins[16];
    _mm256_storeu_si256((__m256i*) &extracted_mins, min_vect);
    short min = extracted_mins[0];
    // find min value in min vector
    for (int i = 1; i < 16; ++i) {
      if (extracted_mins[i] < min)
	min = extracted_mins[i];
    }
    return min;
}

/* This is the list of functions to test */
function_info functions[] = {
    {min_C, "C (local)"},
    // add entries here!
    {min_AVX, "Min with AVX"},
    {NULL, NULL},
};
