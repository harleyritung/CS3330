#include <stdlib.h>

#include <immintrin.h>

#include "dot_product.h"
/* reference implementation in C */
unsigned int dot_product_C(long size, unsigned short * a, unsigned short *b) {
    unsigned int sum = 0;
    for (int i = 0; i < size; ++i) {
        sum += a[i] * b[i];
    }
    return sum;
}

unsigned int dot_product_AVX(long size, unsigned short * a, unsigned short *b) {
    unsigned int sum = 0;
    __m256i partial_sums_vect = _mm256_setzero_si256();
    for (int i = 0; i < size; i+=8) {
      __m128i a_vect = _mm_loadu_si128((__m128i*) &a[i]);
      __m256i a_vect_converted = _mm256_cvtepu16_epi32(a_vect);
      __m128i b_vect = _mm_loadu_si128((__m128i*) &b[i]);
      __m256i b_vect_converted = _mm256_cvtepu16_epi32(b_vect);
      __m256i product_vect = _mm256_mullo_epi32(a_vect_converted, b_vect_converted);
      partial_sums_vect = _mm256_add_epi32(partial_sums_vect, product_vect);
    }
    unsigned int extracted_partial_sums[8];
    _mm256_storeu_si256((__m256i*) &extracted_partial_sums, partial_sums_vect);
    for (int i = 0; i < 8; ++i)
      sum += extracted_partial_sums[i];
    return sum;
}

// add prototypes here!
extern unsigned int dot_product_gcc7_O3(long size, unsigned short * a, unsigned short *b);

/* This is the list of functions to test */
function_info functions[] = {
    {dot_product_C, "C (local)"},
    {dot_product_gcc7_O3, "C (compiled with GCC7.2 -O3 -mavx2)"},
    // add entries here!
    {dot_product_AVX, "Dot product with AVX"},
    {NULL, NULL},
};
